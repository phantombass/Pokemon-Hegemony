##############################################
1px Character Creator by Voltseon
Version 1.0

Credit if used
##############################################
Usage
##############################################
Open any image editing software that uses layers (eg. Paint.NET or Photoshop)
Import the base of the character you want to use (eg. Male/Base/boy_base.png)
Add any clothing and/or hairstyles you want to use
Flatten your layers and recolor anything you want with contiguous disabled
Save it to your game and you're done!
##############################################